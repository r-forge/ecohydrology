GroundHeat <-
function(){
# the heat conducted to the bottom of a snowpack, assumed constant [kJ m-2 d-1]

return(173)
}

